<?php

return [

	'themes_folder' => resource_path('views/themes'),
	'publish_assets' => false

];